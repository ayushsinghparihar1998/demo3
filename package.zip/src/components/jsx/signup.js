import React, { Component } from "react";
import { Nav, NavDropdown, Navbar, Form, FormControl, Button, Image, Container, Row, Col } from "react-bootstrap";
import Righimg from '../../assets/images/sideimg.jpg';


class Signup extends Component {     
  render() {
    return (
        <div className="Signup">      
            <Container>
            
            </Container>
        </div>
    )
  }
}

export default Signup;
