export default {
    paginationPageNumber: 1,
    paginationPageSize: 10,
    itemsCountPerPage: 10,
    pageRangeDisplayed: 5,
    paginationImageSize: 6,
    dassPaginationPageSize: 3,
    dashItemsCountPerPage: 3,
    dashPageRangeDisplayed: 5,

};